const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const db = new sqlite3.Database("database.sqlite");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Inicialização do banco
db.serialize(() => {
  db.run(\`
    CREATE TABLE IF NOT EXISTS providers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      service TEXT
    )
  \`);

  db.run(\`
    CREATE TABLE IF NOT EXISTS residents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      ql TEXT,
      token TEXT
    )
  \`);

  db.run(\`
    CREATE TABLE IF NOT EXISTS ratings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      provider_id INTEGER,
      resident_id INTEGER,
      rating INTEGER,
      comment TEXT
    )
  \`);
});

// Página inicial
app.get("/", (req, res) => {
  db.all("SELECT * FROM providers", (err, providers) => {
    res.render("index", { providers });
  });
});

// Formulário de avaliação
app.get("/avaliar/:id", (req, res) => {
  const providerId = req.params.id;
  db.get("SELECT * FROM providers WHERE id = ?", [providerId], (err, provider) => {
    res.render("avaliar", { provider });
  });
});

app.post("/avaliar/:id", (req, res) => {
  const { name, ql, token, rating, comment } = req.body;
  const providerId = req.params.id;

  db.get("SELECT id FROM residents WHERE name = ? AND ql = ? AND token = ?", [name, ql, token], (err, resident) => {
    if (resident) {
      db.run("INSERT INTO ratings (provider_id, resident_id, rating, comment) VALUES (?, ?, ?, ?)",
        [providerId, resident.id, rating, comment],
        () => res.send("Avaliação registrada com sucesso.")
      );
    } else {
      res.send("Verificação falhou: dados do morador inválidos.");
    }
  });
});

app.listen(3000, () => console.log("Servidor rodando na porta 3000"));